// Generated file. Do not edit!
package org.jraf.klibslack
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.0.4-SNAPSHOT"
